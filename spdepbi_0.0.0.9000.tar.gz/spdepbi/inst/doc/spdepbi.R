## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(spdepbi)

## ------------------------------------------------------------------------
library(sf)
library(spdep)
columbus <- st_read(system.file("extdata/columbus.shp", package="spdepbi")[1], quiet=TRUE)

## ------------------------------------------------------------------------
coords = st_geometry(st_centroid(columbus$geometry))
col_nbq <- poly2nb(columbus)                    # Queen-Style
par.lags1 <- nblag(col_nbq, 6)                  # Order 6
plot(st_geometry(columbus), border="grey")
plot(par.lags1[[5]], coords, add=TRUE, col="red", lty=2)

## ------------------------------------------------------------------------
a.lw <- nb2listw(col_nbq, style="W")
summary(a.lw)

## ------------------------------------------------------------------------
##Rook-Style
columbus <- st_read(system.file("extdata/columbus.shp", package="spdepbi")[1], quiet=TRUE)
plot(st_geometry(columbus))
coords = st_geometry(st_centroid(columbus$geometry))
p1 = st_point(c(8.940741,12.35734))
(p1 = st_sfc(p1))
(polcontain = st_within(p1,columbus))
(myPol = which(as.matrix(polcontain)))
result = columbus[myPol, ]
#Get centroid of selected polygon and plot its ID
centroidsp <- st_geometry(st_centroid(result$geometry))
text(st_coordinates(centroidsp)[,1],st_coordinates(centroidsp)[,2],columbus[myPol,]$POLYID)
col_nbr <- poly2nb(columbus,queen=F)            # rook-style
col.lags10 <- nblag(col_nbr, 10)                # Order 10
#Plot first and second order polygons
plot(st_geometry(columbus[col.lags10[[1]][[myPol]],]), col = "springgreen4", add = TRUE)
plot(st_geometry(columbus[col.lags10[[2]][[myPol]],]), col = "yellow4", add = TRUE)
#Get centroid of first order neighbours
centroids <- st_geometry(st_centroid(columbus[col.lags10[[1]][[myPol]],]$geometry))
#plot text of first order neighbours
text(st_coordinates(centroids)[,1],st_coordinates(centroids)[,2],columbus[col.lags10[[1]][[myPol]],]$POLYID ,cex=0.8)

## ------------------------------------------------------------------------
##Queen-Style
plot(st_geometry(columbus))
coords = st_geometry(st_centroid(columbus$geometry))
p1 = st_point(c(8.940741,12.35734))
(p1 = st_sfc(p1))
(polcontain = st_within(p1,columbus))
(myPol = which(as.matrix(polcontain)))
result = columbus[myPol, ]
#Get centroid of selected polygon and plot its ID
centroidsp <- st_geometry(st_centroid(result$geometry))
text(st_coordinates(centroidsp)[,1],st_coordinates(centroidsp)[,2],columbus[myPol,]$POLYID)
col_nbq1 <- poly2nb(columbus)                   #Queen
col.lags10 <- nblag(col_nbq1, 10)               #Order 10
#Plot first and second order polygons
plot(st_geometry(columbus[col.lags10[[1]][[myPol]],]), col = "springgreen4", add = TRUE)
plot(st_geometry(columbus[col.lags10[[2]][[myPol]],]), col = "yellow4", add = TRUE)
#Get centroid of first order neighbours
centroids <- st_geometry(st_centroid(columbus[col.lags10[[1]][[myPol]],]$geometry))
#plot text of first order neighbours
text(st_coordinates(centroids)[,1],st_coordinates(centroids)[,2],columbus[col.lags10[[1]][[myPol]],]$POLYID ,cex=0.8)

## ------------------------------------------------------------------------
CRIME <- columbus$CRIME
INCOME <- columbus$INC
HOVAL <- columbus$HOVAL

## ----moran.bi, warning=FALSE---------------------------------------------
moran.bi(CRIME,INCOME,a.lw,zero.policy =T)

## ---- fig.cap='Hypothesis Testing - 1', out.width = '350px'--------------
knitr::include_graphics("test1ho.jpg")

## ---- warning=FALSE------------------------------------------------------
set.seed(123)
MBCrime <- moranbi.test(CRIME,INCOME,a.lw,999,graph=T,zero.policy =T,N=1000)

## ---- warning=FALSE------------------------------------------------------
moranbi.test(INCOME,HOVAL,a.lw,999,graph=T,zero.policy =T,N=1000)

## ------------------------------------------------------------------------
CRIME <- as.vector(scale(columbus$CRIME))
INCOME <- as.vector(scale(columbus$INC))
moranbi.plot(CRIME,INCOME,quiet =F,zero.policy =F,listw=a.lw)

## ------------------------------------------------------------------------
CRIME <- columbus$CRIME
INCOME <- columbus$INC
HOVAL <- columbus$HOVAL
localmoran.bi(CRIME, INCOME, a.lw, zero.policy=FALSE, alternative="two.sided")

## ---- fig.cap='Hypothesis Testing - 2', out.width = '350px'--------------
knitr::include_graphics("test5ho.jpg")

## ------------------------------------------------------------------------
moran.cluster(CRIME, a.lw, zero.policy = FALSE, columbus, significant=T)

## ------------------------------------------------------------------------
getis.cluster(CRIME, a.lw, zero.policy = FALSE, columbus, significant=T)

